﻿using Newtonsoft.Json;

namespace Questao2
{
    public class GoalsService
    {
        private static readonly HttpClient _httpClient = new HttpClient();
        public async Task<Goals> ObterGoals(string team, int year, string teamNum, int page = 1)
        {
            string url = $"https://jsonmock.hackerrank.com/api/football_matches?year={year}&{teamNum}={team}&page={page}";

            var response = await _httpClient.GetAsync(url);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var content = await response.Content.ReadAsStringAsync();

                var resulte = JsonConvert.DeserializeObject<Goals>(content);

                return resulte;
            }

            return new Goals();
        }
    }
}

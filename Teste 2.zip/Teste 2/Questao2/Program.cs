﻿using Questao2;

public class Program
{
    public static void Main()
    {
        string teamName = "Paris Saint-Germain";
        int year = 2013;
        int totalGoals = getTotalScoredGoals(teamName, year);

        Console.WriteLine("Team " + teamName + " scored " + totalGoals.ToString() + " goals in " + year);

        teamName = "Chelsea";
        year = 2014;
        totalGoals = getTotalScoredGoals(teamName, year);

        Console.WriteLine("Team " + teamName + " scored " + totalGoals.ToString() + " goals in " + year);

        // Output expected:
        // Team Paris Saint - Germain scored 109 goals in 2013
        // Team Chelsea scored 92 goals in 2014
    }

    public static int getTotalScoredGoals(string team, int year)
    {
        var service = new GoalsService();
        var goalsTeam1 = GetGoalsTeam(team, year, "team1");
        var goalsTeam2 = GetGoalsTeam(team, year, "team2");       

        return goalsTeam1.Result + goalsTeam2.Result;
    }

    private static async Task<int> GetGoalsTeam(string team, int year, string teamNum)
    {
        int total = 0;
        var service = new GoalsService();
        var goalsTeam = await service.ObterGoals(team, year, teamNum);

        for (int page = 2; page <= goalsTeam.Total_pages; page++)
        {
            var goals = await service.ObterGoals(team, year, teamNum, page);
            goalsTeam.Data.AddRange(goals.Data);
        };

        foreach (var item in goalsTeam.Data)
        {
            if (teamNum == "team1")
                total += item.Team1Goals;
            else
                total += item.Team2Goals;
        }
        return total;
    }
}
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Questao5.Application.Commands.Requests;
using Questao5.Tests.Fixture;

namespace Questao5.Tests.Controllers
{
    public class AccountControllerTest
    {
        private readonly ControllerTestsFixture _fixture;

        public AccountControllerTest()
        {
            _fixture = new ControllerTestsFixture();
        }

        [Fact(DisplayName = "Obter deve retornar OK de IEnumerable<Acoounts>")]
        [Trait("Controller", "AccountController")]
        public async Task GetAccounts_ReturnsOkResult()
        {
            // Arrange
            _fixture.SetupController();            

            // Act
            var result = await _fixture.AccountController.GetAccounts();

            // Assert
            Assert.IsType<OkObjectResult>(result);
        }

        [Fact(DisplayName = "Inserir movimenta��o na conta deve retornar OK")]
        [Trait("Controller", "AccountController")]
        public async Task CreateMovement_WithValidCommand_ReturnsOkResult()
        {
            // Arrange
            _fixture.SetupController();
            var command = new CreateMovementCommand(new Guid(), DateTime.Now, "C", 10);

            // Act
            var result = await _fixture.AccountController.CreateMovement(command);

            // Assert
            Assert.IsType<OkResult>(result);
        }      
    }
}
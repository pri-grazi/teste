﻿using MediatR;
using Moq;
using Questao5.Controllers;
using Questao5.Domain.Entities;
using Questao5.Infrastructure.Database.Interfaces;

namespace Questao5.Tests.Fixture
{
    public class ControllerTestsFixture
    {
        public AccountController AccountController { get; set; }
        public Mock<IMediator> Mediator;
        public Mock<IAccountsRepository> AccountsRepository;

        public ControllerTestsFixture()
        {
            Mediator = new Mock<IMediator>();
            AccountsRepository = new Mock<IAccountsRepository>();
        }

        public void SetupController()
        {
            AccountController = new AccountController(Mediator.Object);
            AccountsRepository.Setup(x => x.GetAccounts()).ReturnsAsync(GetListAccounts());
        }                  

        public IEnumerable<Account> GetListAccounts()
        {
            var accounts = new List<Account>();
            var random = new Random();

            for (int i = 0; i < 5; i++)
            {
                var pessoa = new Account
                {
                    IdContaCorrente =  Guid.NewGuid().ToString(),
                    Numero = random.Next(1, 5).ToString(),
                    Nome = $"Pessoa{i + 1}", 
                    Data = DateTime.Today.AddDays(-random.Next(365, 3650)),
                    Ativo = 1
                };

                accounts.Add(pessoa);
            }
            return accounts;
        }       
    }
}

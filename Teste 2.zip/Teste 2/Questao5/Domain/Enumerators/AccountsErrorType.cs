﻿namespace Questao5.Domain.Enumerators
{
    public enum AccountsErrorType
    {
        INVALID_ACCOUNT,
        INACTIVE_ACCOUNT,
        INVALID_VALUE,
        INVALID_TYPE
    }
}

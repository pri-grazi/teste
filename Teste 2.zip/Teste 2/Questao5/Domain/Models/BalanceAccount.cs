﻿namespace Questao5.Domain.Models
{
    public class BalanceAccount
    {
        public string IdContaCorrente { get; set; }
        public string Numero { get; set; }
        public string Nome { get; set; }
        public DateTime Data { get; set; }
        public decimal SaldoAtual { get; set; }
    }
}

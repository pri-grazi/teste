﻿using Questao5.Domain.Enumerators;

namespace Questao5.Domain.Models
{
    public class AccountsException :Exception
    {
        public AccountsErrorType ErrorType { get; }

        public AccountsException(AccountsErrorType errorType, string message)
            : base(message)
        {
            ErrorType = errorType;
        }
    }
}

﻿using Questao5.Domain.Entities;
using Questao5.Domain.Models;

namespace Questao5.Application.Queries.Responses
{
    public record GetBalanceAccountsResult(BalanceAccount balanceAccount);
}

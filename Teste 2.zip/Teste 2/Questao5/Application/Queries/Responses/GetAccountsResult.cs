﻿using Questao5.Domain.Entities;

namespace Questao5.Application.Queries.Responses
{
    public record GetAccountsResult(IEnumerable<Account> account);
}

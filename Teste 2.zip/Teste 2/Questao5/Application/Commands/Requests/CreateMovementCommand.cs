﻿using MediatR;
using Questao5.Application.Commands.Responses;
using System.Linq.Expressions;

namespace Questao5.Application.Commands.Requests
{
    public record CreateMovementCommand(
        Guid IdContaCorrente,
        DateTime DataMovimento,
        string TipoMovimento,
        decimal Valor
        ) : IRequest<CreateMovementResult>;
}

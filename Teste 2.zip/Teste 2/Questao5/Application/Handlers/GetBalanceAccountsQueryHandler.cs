﻿using MediatR;
using Questao5.Application.Queries.Requests;
using Questao5.Application.Queries.Responses;
using Questao5.Domain.Entities;
using Questao5.Domain.Enumerators;
using Questao5.Domain.Models;
using Questao5.Infrastructure.Database.Interfaces;

namespace Questao5.Application.Handlers
{
    public class GetBalanceAccountsQueryHandler : IRequestHandler<GetBalanceAccountsQuery, GetBalanceAccountsResult>
    {
        private readonly IAccountsRepository _accountsRepository;
        private readonly IMovementsRepository _movementsRepository;

        public GetBalanceAccountsQueryHandler(IAccountsRepository accountsRepository, IMovementsRepository movementsRepository)
        {
            _accountsRepository = accountsRepository;
            _movementsRepository = movementsRepository;
        }

        public async Task<GetBalanceAccountsResult> Handle(GetBalanceAccountsQuery query, CancellationToken cancellationToken)
        {
            var conta = await _accountsRepository.GetAccountById(query.id);
            if (conta == null)
            {
                throw new AccountsException(AccountsErrorType.INVALID_ACCOUNT, "Conta corrente não encontrada.");
            }
            if (conta.Ativo < 1)
            {
                throw new AccountsException(AccountsErrorType.INACTIVE_ACCOUNT, "Conta corrente está inativa.");
            }
        
            var accountsMovements = await _movementsRepository.GetBalanceAccountsById(query.id);
            
            decimal saldo = CalcularSaldo(accountsMovements);

            var balanceAccounts =  new BalanceAccount
            {
                IdContaCorrente = conta.IdContaCorrente,
                Numero = conta.Numero,
                Nome = conta.Nome,
                Data = DateTime.Now,
                SaldoAtual = saldo
            };

            return new GetBalanceAccountsResult(balanceAccounts);
        }

        private decimal CalcularSaldo(IEnumerable<Movement> accountsMovements)
        {
            decimal saldo = 0.00m;

            foreach (var item in accountsMovements)
            {
                if (item.TipoMovimento == "C")
                {
                    saldo += item.Valor;
                }
                else if (item.TipoMovimento == "D")
                {
                    saldo -= item.Valor;
                }
            }

            return saldo;
        }
    }   
}

﻿using MediatR;
using Questao5.Application.Queries.Requests;
using Questao5.Application.Queries.Responses;
using Questao5.Infrastructure.Database.Interfaces;

namespace Questao5.Application.Handlers
{
    public class GetAccountsQueryHandler : IRequestHandler<GetAccountsQuery, GetAccountsResult>
    {
        private readonly IAccountsRepository _accountsRepository;

        public GetAccountsQueryHandler(IAccountsRepository accountsRepository)
        {
            _accountsRepository = accountsRepository;
        }

        public async Task<GetAccountsResult> Handle(GetAccountsQuery query, CancellationToken cancellationToken)
        {
            var result = await _accountsRepository.GetAccounts();

            return new GetAccountsResult(result);
        }
    }
}

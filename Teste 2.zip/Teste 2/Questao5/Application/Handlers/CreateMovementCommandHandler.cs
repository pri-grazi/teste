﻿using MediatR;
using Questao5.Application.Commands.Requests;
using Questao5.Application.Commands.Responses;
using Questao5.Domain.Enumerators;
using Questao5.Domain.Models;
using Questao5.Infrastructure.Database.Interfaces;

namespace Questao5.Application.Handlers
{
    public class CreateMovementCommandHandler : IRequestHandler<CreateMovementCommand, CreateMovementResult>
    {
        private readonly IAccountsRepository _accountsRepository;
        private readonly IMovementsRepository _movementsRepository;

        public CreateMovementCommandHandler(IAccountsRepository customerRepository, IMovementsRepository movementsRepository)
        {
            _accountsRepository = customerRepository;
            _movementsRepository = movementsRepository;
        }

        public async Task<CreateMovementResult> Handle(CreateMovementCommand request, CancellationToken cancellationToken)
        {           
            var conta = _accountsRepository.GetAccountById(request.IdContaCorrente.ToString());

            if (conta.Result == null)
            {
                throw new AccountsException(AccountsErrorType.INVALID_ACCOUNT, "A conta corrente não está cadastrada.");
            }

            if (conta.Result.Ativo < 1)
            {
                throw new AccountsException(AccountsErrorType.INACTIVE_ACCOUNT, "A conta corrente está inativa.");
            }

            if (request.Valor <= 0)
            {
                throw new AccountsException(AccountsErrorType.INVALID_VALUE, "O valor da movimentação deve ser positivo.");
            }

            if (request.TipoMovimento != "D" && request.TipoMovimento != "C")
            {
                throw new AccountsException(AccountsErrorType.INVALID_TYPE, "Apenas os tipos D (débito) ou C (crédito) são permitidos.");
            }

            var result = await _movementsRepository.CreateMovement(request.IdContaCorrente, request.DataMovimento, request.TipoMovimento, request.Valor);
          
            return new CreateMovementResult(result);
        }
    }
}

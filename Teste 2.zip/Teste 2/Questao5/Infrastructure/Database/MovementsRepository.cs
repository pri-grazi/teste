﻿using Dapper;
using Microsoft.Data.Sqlite;
using Questao5.Domain.Entities;
using Questao5.Infrastructure.Database.Interfaces;
using Questao5.Infrastructure.Sqlite;

namespace Questao5.Infrastructure.Database
{
    public class MovementsRepository : IMovementsRepository
    {
        private readonly DatabaseConfig databaseConfig;

        public MovementsRepository(DatabaseConfig databaseConfig)
        {
            this.databaseConfig = databaseConfig;
        }  

        public async Task<IEnumerable<Movement>> GetBalanceAccountsById(string id)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            string query = "SELECT * FROM movimento WHERE idcontacorrente = @Id";

            return await connection.QueryAsync<Movement>(query, new { Id = id.ToUpper() });
        }
      
        public async Task<Movement> CreateMovement(Guid idContaCorrente, DateTime dataMovimento, string tipoMovimento, decimal valor)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);
           
            string insertQuery = "INSERT INTO movimento (idmovimento, idcontacorrente, datamovimento, tipomovimento, valor) " +
                "VALUES (@IdMovimento, @IdContaCorrente, @DataMovimento, @TipoMovimento, @Valor);";

            var movement = await connection.ExecuteScalarAsync<Movement>(insertQuery, new { IdMovimento = Guid.NewGuid().ToString(), IdContaCorrente = idContaCorrente, DataMovimento = DateTime.Now, TipoMovimento = tipoMovimento, Valor = valor });

            return movement;
        }
    }
}

﻿using Questao5.Domain.Entities;

namespace Questao5.Infrastructure.Database.Interfaces
{
    public interface IMovementsRepository
    {
        Task<IEnumerable<Movement>> GetBalanceAccountsById(string id);
        Task<Movement> CreateMovement(Guid idContaCorrente, DateTime dataMovimento, string tipoMovimento, decimal valor);
    }
}

﻿using Questao5.Domain.Entities;

namespace Questao5.Infrastructure.Database.Interfaces
{
    public interface IAccountsRepository
    {
        Task<IEnumerable<Account>> GetAccounts();
        Task<Account> GetAccountById(string id);
    }
}

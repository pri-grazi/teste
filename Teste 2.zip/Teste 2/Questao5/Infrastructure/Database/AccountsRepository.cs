﻿using Dapper;
using Microsoft.Data.Sqlite;
using Questao5.Domain.Entities;
using Questao5.Infrastructure.Database.Interfaces;
using Questao5.Infrastructure.Sqlite;

namespace Questao5.Infrastructure.Database
{
    public class AccountsRepository : IAccountsRepository
    {
        private readonly DatabaseConfig databaseConfig;

        public AccountsRepository(DatabaseConfig databaseConfig)
        {
            this.databaseConfig = databaseConfig;
        }

        public async Task<IEnumerable<Account>> GetAccounts()
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            return await connection.QueryAsync<Account>("SELECT * FROM Contacorrente;");
        }      

        public async Task<Account> GetAccountById(string id)
        {
            using var connection = new SqliteConnection(databaseConfig.Name);

            string query = "SELECT * FROM contacorrente WHERE idcontacorrente = @Id";

            var conta = await connection.QuerySingleOrDefaultAsync<Account>(query, new { Id = id.ToUpper() });

            return conta;
        }
    }
}

﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Questao5.Application.Commands.Requests;
using Questao5.Application.Queries.Requests;
using Questao5.Domain.Models;

namespace Questao5.Controllers
{
    [Route("api/account")]
    public class AccountController : ControllerBase
    {
        private readonly IMediator _mediator;

        public AccountController(IMediator mediator)
        {
            _mediator = mediator;
        }
    
        [HttpGet("Contas")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetAccounts()
        {
            var query = new GetAccountsQuery();
            var accounts = await _mediator.Send(query);
            return Ok(accounts);
        }

        [HttpGet("Saldo")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetBalanceById(string id)
        {
            try
            {
                var query = new GetBalanceAccountsQuery(id);
                var response = await _mediator.Send(query);
                return Ok(response);
            }
            catch (AccountsException ex)
            {
                return BadRequest(new { Mensagem = ex.Message, Tipo = ex.ErrorType.ToString() });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Mensagem = "Ocorreu um erro interno no servidor." });
            }            
        }

        [HttpPost("Movimentação")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CreateMovement([FromBody] CreateMovementCommand command)
        {            
            try
            {
                var accountsMovement = await _mediator.Send(command);
                return Ok();
            }
            catch (AccountsException ex)
            {
                return BadRequest(new { Mensagem = ex.Message, Tipo = ex.ErrorType.ToString() });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Mensagem = "Ocorreu um erro interno no servidor." });
            }
        }       
    }
}

﻿namespace Questao1
{
    public class ContaBancaria {
        public int Numero { get; set; }      
        public string Titular { get; set; }
        public double Saldo { get; private set;}

        public ContaBancaria(int numero, string titular, double depositoInicial = 0)
        {
            Numero = numero;
            Titular = titular;
            Saldo = depositoInicial;
        }    

        public double Saque(double quantia){
            return Saldo = Saldo - quantia - 3.5;
        }   

        public double Deposito(double quantia){
            return Saldo = Saldo + quantia;
        } 
    }
}
